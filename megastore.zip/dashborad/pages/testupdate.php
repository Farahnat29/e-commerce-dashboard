<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form role="form" action="" method="post">
                <div class="mb-3">
                  <input type="text" name="name" class="form-control form-control-lg" placeholder="name" >
                </div>
               
                <div class="mb-3">
                  <input type="text" name="img" class="form-control form-control-lg">
                </div>
                <div class="mb-3">
                  <input type="text" name="status" class="form-control form-control-lg" placeholder="Password" >
                </div>
                <div class="text-center">
                  <input type="submit" class="btn btn-dark">
                </div>
              </form>
    
</body>
</html>